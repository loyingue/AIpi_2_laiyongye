import setuptools


setuptools.setup(
    name="yoloall",
    version="1.2",
    author="loyingue",
    author_email="1781056838@qq.com",
    description="",
    long_description="yolov5v6v7v8",
    long_description_content_type="yoloall",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
