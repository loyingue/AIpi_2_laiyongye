from yoloall import testtheku
from yoloall import myv5
import numpy

testtheku.printku()

myv5.v5detect()