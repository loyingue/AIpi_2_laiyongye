def printku():
    print('this is a ku')

print("Welcome")
