import subprocess

def v6train(dic_v6='E:\software_eng\yolo\YOLOv6-main\YOLOv6-main/tools/train.py', data_dic = 'E:\software_eng\yolo\dataset/tennis-court-detection.v9i.mt-yolov6/data.yaml', conf_dic = 'E:\software_eng\yolo\YOLOv6-main\YOLOv6-main\configs/yolov6s.py'):
    command = "python " + dic_v6 + " --conf " + conf_dic + " --data " + data_dic + " --fuse_ab --device 0"
    process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    output, error = process.communicate()
    print(output.decode())
    print(error.decode())

def v6test(dic_v6='E:\software_eng\yolo\YOLOv6-main\YOLOv6-main/tools/train.py', weights_dic = 'E:\software_eng\yolo\dataset/tennis-court-detection.v9i.mt-yolov6/data.yaml', source_dic = " "):
    command = "python " + dic_v6 + " --weights " + weights_dic + " --source " + source_dic + " --device 0"
    process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    output, error = process.communicate()
    print(output.decode())
    print(error.decode())