import subprocess

def v7train(dic_v7='E:\software_eng\yolo\yolov7-main\yolov7-main/train.py', data_dic = 'E:\software_eng\yolo\dataset/tennis-court-detection.v9i.yolov7pytorch\data.yaml', cfg_dic = 'E:\software_eng\yolo\yolov7-main\yolov7-main/cfg/training/yolov7.yaml', weights_dic='E:\software_eng\yolo\yolov7-main\yolov7-main/yolov7.pt', hyp_dic='E:\software_eng\yolo\yolov7-main\yolov7-main/data/hyp.scratch.p5.yaml'):
    command = "python " + dic_v7 + " --workers 8 --device 0 --batch-size 32 " + " --data " + data_dic + " --cfg " + cfg_dic + " --weights " + weights_dic +" --hyp " + hyp_dic
    process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    output, error = process.communicate()
    print(output.decode())
    print(error.decode())

def v7test(dic_v6='E:\software_eng\yolo\yolov7-main\yolov7-main/detect.py', weights_dic = 'E:\software_eng\yolo\dataset/tennis-court-detection.v9i.mt-yolov6/data.yaml', source_dic = " "):
    command = "python " + dic_v6 + " --weights " + weights_dic + " --source " + source_dic
    process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    output, error = process.communicate()
    print(output.decode())
    print(error.decode())

