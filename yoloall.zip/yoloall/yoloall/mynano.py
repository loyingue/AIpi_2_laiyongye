import subprocess


def nanosetup(dic_nano = 'setup.py'):
    command = "python " + dic_nano
    process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    output, error = process.communicate()
    print(output.decode())
    print(error.decode())

def nanotrain(dic_nano='tools/train.py', conf_dic = ''):
    command = "python " + dic_nano + " " + conf_dic
    process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    output, error = process.communicate()
    print(output.decode())
    print(error.decode())

