
import subprocess


def v5detect(dic_v5='E:\software_eng\yolo\yolov5-master\yolov5-master/detect.py', source_dic='E:\software_eng\yolo\dataset/tennis-court-detection.v9i.yolov5pytorch/test\images\im.jpg', weights_dic='E:\software_eng\yolo\yolov5-master\yolov5-master/runs/train/exp9/weights/best.pt'):
    command = "python " + dic_v5 + " --source " + source_dic + " --weights " + weights_dic
    process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    output, error = process.communicate()
    print(output.decode())
    print(error.decode())

def v5train(dic_v5='E:\software_eng\yolo\yolov5-master\yolov5-master/train.py', data_dic = 'data.yaml', cfg_dic = 'models/yolov5n.yaml', weights_dic = 'yolov5n.pt'):
    command = "python " + dic_v5 + " --data " + data_dic +" --cfg " + cfg_dic + " --weights " + weights_dic
    process = subprocess.Popen(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    output, error = process.communicate()
    print(output.decode())
    print(error.decode())